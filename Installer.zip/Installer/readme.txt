I hope you like i had a lot of fun making it
Please enter your gemini api key to use it